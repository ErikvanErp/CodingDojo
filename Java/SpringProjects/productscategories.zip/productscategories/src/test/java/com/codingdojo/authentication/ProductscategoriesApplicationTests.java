package com.codingdojo.authentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductscategoriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
